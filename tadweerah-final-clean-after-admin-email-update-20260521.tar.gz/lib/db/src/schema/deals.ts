import {
  pgTable,
  text,
  timestamp,
  uuid,
  pgEnum,
  numeric,
  index,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { companiesTable } from "./companies";
import { wasteListingsTable } from "./waste-listings";
import { listingOffersTable } from "./listing-offers";

export const dealSettlementTypeEnum = pgEnum("deal_settlement_type", [
  "fixed",
  "by_weight",
  "revenue_share",
]);

export const dealStatusEnum = pgEnum("deal_status", [
  "active",
  "payment_submitted",
  "payment_confirmed",
  "dispatched",
  "receipt_pending",
  "completed",
  "expired",
  "cancelled",
]);

export const dealsTable = pgTable(
  "deals",
  {
    id: uuid("id").primaryKey().defaultRandom(),

    offer_id: uuid("offer_id")
      .notNull()
      .unique()
      .references(() => listingOffersTable.id, { onDelete: "restrict" }),

    listing_id: uuid("listing_id")
      .notNull()
      .references(() => wasteListingsTable.id, { onDelete: "restrict" }),

    producer_company_id: uuid("producer_company_id")
      .notNull()
      .references(() => companiesTable.id, { onDelete: "restrict" }),

    buyer_company_id: uuid("buyer_company_id")
      .notNull()
      .references(() => companiesTable.id, { onDelete: "restrict" }),

    settlement_type: dealSettlementTypeEnum("settlement_type").notNull(),

    price_per_unit: numeric("price_per_unit", {
      precision: 12,
      scale: 3,
    }).notNull(),

    estimated_amount: numeric("estimated_amount", {
      precision: 14,
      scale: 3,
    }).notNull(),

    actual_quantity: numeric("actual_quantity", { precision: 12, scale: 3 }),

    final_amount: numeric("final_amount", { precision: 14, scale: 3 }),

    status: dealStatusEnum("status").notNull().default("active"),

    payment_confirmed_at: timestamp("payment_confirmed_at", {
      withTimezone: true,
    }),
    payment_confirmed_by: uuid("payment_confirmed_by").references(
      () => companiesTable.id,
      { onDelete: "restrict" },
    ),

    /** Bank transfer reference number or payment transaction ID (required when confirming payment). */
    payment_reference: text("payment_reference"),

    /** URL to uploaded payment proof document / screenshot (optional). */
    payment_proof_url: text("payment_proof_url"),

    /** When the buyer submitted the payment reference (active → payment_submitted). */
    payment_submitted_at: timestamp("payment_submitted_at", { withTimezone: true }),

    /** Buyer company that submitted the payment reference. */
    payment_submitted_by: uuid("payment_submitted_by").references(
      () => companiesTable.id,
      { onDelete: "restrict" },
    ),

    dispatched_at: timestamp("dispatched_at", { withTimezone: true }),
    dispatched_by: uuid("dispatched_by").references(() => companiesTable.id, {
      onDelete: "restrict",
    }),

    received_at: timestamp("received_at", { withTimezone: true }),
    received_by: uuid("received_by").references(() => companiesTable.id, {
      onDelete: "restrict",
    }),

    /**
     * Timestamp when the buyer called confirm-receipt (dispatched → receipt_pending).
     * Used by the hourly job to auto-complete the deal after 48 hours if no dispute is filed.
     */
    receipt_pending_since: timestamp("receipt_pending_since", { withTimezone: true }),

    /**
     * Set when producer or admin cancels the deal before dispatch.
     * Terminal status: no further transitions after cancelled.
     */
    cancelled_at: timestamp("cancelled_at", { withTimezone: true }),

    /**
     * One-time extension: producer can extend the deal deadline once, before dispatch.
     * extended_until replaces the normal SLA deadline for active/payment_confirmed states.
     * extension_count tracks how many times the deal has been extended (max 1).
     */
    extended_until: timestamp("extended_until", { withTimezone: true }),
    extension_count: integer("extension_count").notNull().default(0),

    /**
     * Set to true when the pre-expiry notification has been sent (3 calendar days before deadline).
     * Prevents duplicate pre-expiry alerts from the hourly job.
     */
    pre_expiry_notified: boolean("pre_expiry_notified").notNull().default(false),

    /**
     * Transport Smart-Assist decision.
     * null      = no decision yet (default)
     * 'not_required' = producer/buyer explicitly opted out of transport
     * When a transport_request is created, this field stays null (transport exists).
     */
    transport_decision: text("transport_decision"),

    /**
     * VAT financial fields — computed at deal creation from estimated_amount.
     * vat_rate    = decimal fraction (e.g. 0.15 = 15%)
     * vat_amount  = estimated_amount × vat_rate
     * total_amount = estimated_amount + vat_amount
     * Null for deals created before VAT fields were added (legacy rows).
     * Do NOT change price_per_unit or estimated_amount — they remain pre-VAT.
     */
    vat_rate: numeric("vat_rate", { precision: 5, scale: 4 }),
    vat_amount: numeric("vat_amount", { precision: 14, scale: 3 }),
    total_amount: numeric("total_amount", { precision: 14, scale: 3 }),

    created_at: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updated_at: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    idx_deals_listing: index("idx_deals_listing_id").on(table.listing_id),
    idx_deals_producer: index("idx_deals_producer_company_id").on(
      table.producer_company_id,
    ),
    idx_deals_buyer: index("idx_deals_buyer_company_id").on(
      table.buyer_company_id,
    ),
  }),
);

export type Deal = typeof dealsTable.$inferSelect;
