import {
  Recycle,
  Package,
  MapPin,
  Tag,
  Building2,
  ChevronLeft,
  ChevronRight,
  Scale,
  Gavel,
  ShoppingBag,
  Shield,
  TrendingUp,
  TrendingDown,
  Lock,
  MessageSquare,
  Calendar,
  Truck,
} from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useT } from "@/i18n";
import { fmtNumber } from "@/lib/format";
import { listingRef } from "@/lib/listing-ref";
import { LocationLink } from "@/components/location-link";
import type { WasteListing } from "@workspace/api-client-react";

interface ListingCardProps {
  listing: WasteListing;
  /** Show the company name (marketplace) or hide it (my listings). */
  showCompany?: boolean;
  /** Navigate to this href when the card is clicked. */
  href?: string;
  /** Footer slot — typically actions like "Close listing". */
  footer?: React.ReactNode;
}

export function ListingCard({
  listing,
  showCompany = true,
  href,
  footer,
}: ListingCardProps) {
  const { t, lang } = useT();
  const isOpen = listing.status === "open";
  const isRtl = lang === "ar";
  const imageUrl = (listing as WasteListing & { image_url?: string }).image_url;
  const myRank = (listing as WasteListing & { my_rank?: number }).my_rank;
  const myOfferPrice = (listing as WasteListing & { my_offer_price?: string | number | null }).my_offer_price;
  const highestOfferPrice = (listing as WasteListing & { highest_offer_price?: number | null }).highest_offer_price;
  const highestOfferTotal = (listing as WasteListing & { highest_offer_total?: number | null }).highest_offer_total;
  const requiredServices = (listing as WasteListing & { required_services?: Array<{ id: string; name_ar: string; name_en: string; requires_license?: boolean }> }).required_services ?? [];
  const targetingType = (listing as WasteListing & { targeting_type?: string }).targeting_type ?? "open";
  const eligibleCompanyType = (listing as WasteListing & { eligible_company_type?: string }).eligible_company_type ?? "ALL";
  const materialCategoryNameAr = (listing as WasteListing & { material_category_name_ar?: string | null }).material_category_name_ar;
  const materialCategoryNameEn = (listing as WasteListing & { material_category_name_en?: string | null }).material_category_name_en;
  const materialCategoryName = lang === "ar" ? materialCategoryNameAr : materialCategoryNameEn;
  const offersCount = (listing as WasteListing & { offer_count?: number }).offer_count ?? 0;

  const isFixed = listing.pricing_model === "fixed";
  const qty = Number(listing.quantity);
  const unitLabel = listing.unit ? ` / ${t(`unit.${listing.unit}`)}` : "";

  function fmtOffer(pricePerUnit: number | null | undefined, total?: number | null): string | null {
    if (pricePerUnit == null) return null;
    if (isFixed) {
      const tot = total ?? Number(pricePerUnit) * qty;
      return `${fmtNumber(tot)} ${t("listing.sar")}`;
    }
    return `${fmtNumber(pricePerUnit)} ${t("listing.sar")}${unitLabel}`;
  }

  const inner = (
    <Card
      className={`border-card-border bg-card overflow-hidden transition-shadow ${
        href ? "hover:shadow-md cursor-pointer" : ""
      }`}
    >
      {/* Listing image — always shown; falls back to a material-icon placeholder */}
      <div className="h-36 w-full shrink-0 overflow-hidden bg-muted">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={t(`material.${listing.material}`)}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <Recycle className="h-12 w-12 text-muted-foreground/30" />
          </div>
        )}
      </div>

      <CardContent className="flex flex-col gap-3 p-4">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-secondary/10 text-secondary">
              <Recycle className="h-4 w-4" />
            </span>
            <div className="flex flex-col">
              <h3 className="text-base font-semibold text-card-foreground">
                {t(`material.${listing.material}`)}
              </h3>
              <span className="text-xs text-muted-foreground">
                {listingRef(listing.id)}
              </span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            <Badge variant={isOpen ? "secondary" : "outline"}>
              {t(`status.${listing.status}`)}
            </Badge>
            {targetingType !== "open" && (
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-700">
                <Lock className="h-2.5 w-2.5" />
                {t(`listing.targeting.${targetingType}`)}
              </span>
            )}
            {eligibleCompanyType === "LICENSED_ONLY" && (
              <span className="inline-flex items-center gap-1 rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-medium text-blue-700">
                <Shield className="h-2.5 w-2.5" />
                {t("listing.eligible.badge")}
              </span>
            )}
            {(() => {
              const tr = (listing as WasteListing & { transport_responsibility?: string }).transport_responsibility;
              return tr ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600">
                  <Truck className="h-2.5 w-2.5" />
                  {t(`listing.transport_responsibility.${tr}`)}
                </span>
              ) : null;
            })()}
          </div>
        </div>

        {/* Details grid */}
        <div className="grid gap-2 text-sm text-muted-foreground">
          {materialCategoryName && (
            <div className="flex items-center gap-2">
              <Recycle className="h-4 w-4 shrink-0 text-secondary/70" />
              <span className="text-xs font-medium text-secondary/80 bg-secondary/10 px-2 py-0.5 rounded-full">
                {materialCategoryName}
              </span>
            </div>
          )}
          <div className="flex items-center gap-2">
            <Package className="h-4 w-4 shrink-0" />
            <span>
              {listing.quantity} {listing.unit ? t(`unit.${listing.unit}`) : ""}
            </span>
          </div>
          <div className="flex flex-col gap-0.5">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 shrink-0" />
              <span>{listing.city}</span>
              {(listing as WasteListing & { google_maps_url?: string | null }).google_maps_url?.startsWith("https://") && (
                <a
                  href={(listing as WasteListing & { google_maps_url?: string | null }).google_maps_url!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ms-auto text-xs text-primary hover:underline font-medium shrink-0"
                  onClick={(e) => e.stopPropagation()}
                >
                  ↗ {t("listing.location.open_maps")}
                </a>
              )}
            </div>
            {(listing as WasteListing & { material_location_address?: string | null }).material_location_address && (
              <p className="ps-6 text-xs text-muted-foreground/70 leading-tight">
                <LocationLink
                  address={(listing as WasteListing & { material_location_address?: string | null }).material_location_address}
                  city={listing.city}
                  mapsUrl={(listing as WasteListing & { google_maps_url?: string | null }).google_maps_url}
                  stopPropagation
                />
              </p>
            )}
            {(listing as WasteListing & { material_location_notes?: string | null }).material_location_notes && (
              <p className="ps-6 text-xs text-muted-foreground/50 italic leading-tight">
                {(listing as WasteListing & { material_location_notes?: string | null }).material_location_notes}
              </p>
            )}
          </div>
          {listing.created_at && (
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 shrink-0" />
              <span>
                {new Date(listing.created_at).toLocaleDateString(
                  lang === "ar" ? "ar-SA-u-nu-latn" : "en-US",
                  { year: "numeric", month: "short", day: "numeric" },
                )}
              </span>
            </div>
          )}
          {listing.price_hint != null && (
            <div className="flex items-center gap-2">
              <Tag className="h-4 w-4 shrink-0" />
              <span>
                {fmtNumber(listing.price_hint)} {t("listing.sar")}{listing.unit ? ` / ${t(`unit.${listing.unit}`)}` : ""}
              </span>
            </div>
          )}
          {listing.pricing_model && (
            <div className="flex items-center gap-2">
              <Scale className="h-4 w-4 shrink-0" />
              <span
                className={`text-xs font-medium px-1.5 py-0.5 rounded ${
                  listing.pricing_model === "fixed"
                    ? "bg-secondary/15 text-secondary"
                    : "bg-primary/10 text-primary"
                }`}
              >
                {t(`listing.pricing_model.${listing.pricing_model}`)}
              </span>
              {listing.pricing_model === "revenue_share" && listing.revenue_share_pct != null && (
                <span className="text-xs text-muted-foreground">
                  {listing.revenue_share_pct}%
                </span>
              )}
            </div>
          )}
          {(() => {
            const saleType = (listing as WasteListing & { sale_type?: string }).sale_type ?? "auction";
            return (
              <div className="flex items-center gap-2">
                {saleType === "auction" ? (
                  <Gavel className="h-4 w-4 shrink-0" />
                ) : (
                  <ShoppingBag className="h-4 w-4 shrink-0" />
                )}
                <span
                  className={`text-xs font-medium px-1.5 py-0.5 rounded ${
                    saleType === "auction"
                      ? "bg-primary/10 text-primary"
                      : "bg-secondary/15 text-secondary"
                  }`}
                >
                  {t(`listing.sale_type.${saleType}`)}
                </span>
              </div>
            );
          })()}
          {showCompany && (
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 shrink-0" />
              <span>{listing.company_name ?? "—"}</span>
            </div>
          )}
          {isOpen && (
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 shrink-0" />
              <span>
                {offersCount > 0
                  ? `${offersCount} ${t("listing.card.offers_count")}`
                  : t("listing.card.no_offers")}
              </span>
            </div>
          )}
        </div>

        {/* Required services badges */}
        {requiredServices.length > 0 && (
          <div className="flex flex-wrap gap-1.5 border-t border-border pt-3">
            <span className="text-xs text-muted-foreground me-1 self-center">{t("listing.required_services.label")}:</span>
            {requiredServices.map((svc) => (
              <span
                key={svc.id}
                className="inline-flex items-center gap-1 rounded-full border border-amber-300 bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700"
              >
                {svc.requires_license && <Shield className="h-3 w-3" />}
                {lang === "ar" ? svc.name_ar : svc.name_en}
              </span>
            ))}
          </div>
        )}

        {/* Bid status — shown when viewer has bid */}
        {myRank != null && (
          <div className={`rounded-lg border px-3 py-2 space-y-1 ${
            myRank === 1
              ? "border-secondary/40 bg-secondary/10 text-secondary"
              : "border-muted text-muted-foreground bg-muted/30"
          }`}>
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                {myRank === 1 ? (
                  <TrendingUp className="h-4 w-4 shrink-0" />
                ) : (
                  <TrendingDown className="h-4 w-4 shrink-0" />
                )}
                <span className="text-xs font-semibold">
                  {myRank === 1 ? t("listing.bid.top") : t("listing.bid.not_top")}
                </span>
              </div>
              {myOfferPrice != null && (
                <span className="text-xs font-medium">
                  {t("listing.bid.mine.label")}: {fmtOffer(Number(myOfferPrice))}
                </span>
              )}
            </div>
            {myRank > 1 && highestOfferPrice != null && (
              <p className="text-xs text-muted-foreground ps-5">
                {isFixed ? (lang === "ar" ? "الإجمالي" : "Total") : t("listing.bid.highest.label")}:{" "}
                <span className="font-semibold">{fmtOffer(highestOfferPrice, highestOfferTotal)}</span>
              </p>
            )}
          </div>
        )}

        {/* Highest offer context — viewer hasn't bid but there are offers */}
        {myRank == null && highestOfferPrice != null && (
          <div className="flex items-center gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2">
            <TrendingUp className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            <span className="text-xs text-muted-foreground">
              {isFixed ? (lang === "ar" ? "الإجمالي" : "Total") : t("listing.bid.highest.label")}:{" "}
              <span className="font-semibold text-foreground">
                {fmtOffer(highestOfferPrice, highestOfferTotal)}
              </span>
            </span>
          </div>
        )}

        {/* Footer actions (e.g. Close listing button) — stop propagation so card link doesn't fire */}
        {footer && (
          <div
            className="mt-1 flex flex-col gap-2"
            onClick={(e) => e.stopPropagation()}
          >
            {footer}
          </div>
        )}

        {/* Show "View details" chevron only when there's no href wrapper (footer-only cards) */}
        {!href && footer && null}
        {href && !footer && (
          <div className="flex items-center justify-end gap-1 text-xs text-primary/70 mt-1">
            <span>{t("listing.viewDetail")}</span>
            {isRtl ? (
              <ChevronLeft className="h-3.5 w-3.5" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5" />
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (href) {
    return (
      <Link to={href} className="block">
        {inner}
      </Link>
    );
  }

  return inner;
}
